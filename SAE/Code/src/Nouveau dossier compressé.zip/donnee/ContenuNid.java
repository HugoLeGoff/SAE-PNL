package donnee;
/**
 * Enumeration des ContenuNid.
 */
public enum ContenuNid {
	OEUF,
	POUSSIN,
	NID_SEUL
}