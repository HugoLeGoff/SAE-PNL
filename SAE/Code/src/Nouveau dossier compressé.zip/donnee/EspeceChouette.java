package donnee;
/**
 * Enumeration des EspeceChouette.
 */
public enum EspeceChouette {
	EFFRAIE,
	CHEVECHE,
	HULOTTE
}