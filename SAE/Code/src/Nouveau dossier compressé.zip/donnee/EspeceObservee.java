package donnee;
/**
 * Enumeration des EspeceObservee.
 */
public enum EspeceObservee {
	LOUTRE,
	BATRACIEN,
	CHOUETTE,
	GCI,
	HIPPOCAMPE
}