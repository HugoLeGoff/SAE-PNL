package donnee;
/**
 * Enumeration des IndiceLoutre.
 */
public enum IndiceLoutre {
	POSITIF,
	NEGATIF,
	NON_PROSPECTION
}