package donnee;
/**
 * Enumeration des Sexe;
 */
public enum Sexe {
	MALE,
	FEMELLE,
	INCONNU
}