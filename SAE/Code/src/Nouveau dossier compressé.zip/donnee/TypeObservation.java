package donnee;
/**
 * Enumeration des TypesObservation.
 */
public enum TypeObservation {
	SONORE,
	VISUELLE,
	SONORE_VISUELLE
}