package donnee;
/**
 * Enumeration des ContenuNid.
 */
public enum ContenuNid {
	/**
	 * oeuf du nid
	 */
	OEUF,
	/**
	 * poussin du nid
	 */
	POUSSIN,
	/**
	 * nid seul
	 */
	NID_SEUL
}