package donnee;
/**
 * Enumeration des EspeceBatracien.
 */
public enum EspeceBatracien {
	/**
	 * calamite
	 */
	CALAMITE,
	/**
	 * pelodyte
	 */
	PELODYTE
}