package donnee;
/**
 * Enumeration des EspeceChouette.
 */
public enum EspeceChouette {
	/**
	 * effraie
	 */
	EFFRAIE,
	/**
	 * cheveche
	 */
	CHEVECHE,
	/**
	 * hulotte
	 */
	HULOTTE
}