package donnee;
/**
 * Enumeration des EspeceHippocampe.
 */
public enum EspeceHippocampes {
	/**
	 * SYNGNATHUS_ACTUS
	 */
	SYNGNATHUS_ACTUS,
	/**
	 * HIPPOCAMPUS_GUTTULATUS
	 */
	HIPPOCAMPUS_GUTTULATUS,
	/**
	 * HIPPOCAMPUS_HIPPOCAMPUS
	 */
	HIPPOCAMPUS_HIPPOCAMPUS,
	/**
	 * ENTERURUS_AEQUOREUS
	 */
	ENTERURUS_AEQUOREUS
}