package donnee;
/**
 * Enumeration des Peche.
 */
public enum Peche {
	/**
	 * casier crevettes
	 */
	CASIER_CREVETTES,
	/**
	 * casier morgates
	 */
	CASIER_MORGATES,
	/**
	 * petit filer
	 */
	PETIT_FILET,
	/**
	 * verveux anguilles
	 */
	VERVEUX_ANGUILLES,
	/**
	 * non rensigne
	 */
	NON_RENSEIGNE
}