package donnee;
/**
 * Enumeration des Sexe;
 */
public enum Sexe {
	/**
	 * male
	 */
	MALE,
	/**
	 * femelle
	 */
	FEMELLE,
	/**
	 * inconnu
	 */
	INCONNU
}